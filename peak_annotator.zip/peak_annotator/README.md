Peak Annotator Tool – Setup Instructions

This tool lets you visually label ABR peaks from pre-processed data using an interactive plot.

Requirements:
-------------
- Python 3.8 or later
- PyCharm

Setup Steps:
------------
1. Unzip the folder anywhere on your computer
2. Open PyCharm
3. In PyCharm, go to File --> Open, and select the unzipped "peak_annotator" folder
4. PyCharm will probably detect the "requirements.txt" file and prompt you to install packages
   - Click "Install requirements" when prompted, otherwise you can do this manually in the terminal with "pip install -r reqirements.txt"

Running the Tool:
-----------------
1. In PyCharm, open the file "peak_annotator.py"
2. Click the green Run button at the top right to start the program
3. A window will open showing waveform plots:
   - Click once on each trace to label the peak
   - When all traces have been labeled, press the "Next" button
   - Repeat for each subject
4. Results will be saved automatically to:
   - "peak_annotator/csv/manual_peak_picks.csv" – your peak labels
   - "peak_annotator/abr_plots" – images of the plots with your annotations

Troubleshooting:
----------------
If the plot window does not appear:
- In PyCharm, go to Run → Edit Configurations
- Check the option: "Emulate terminal in output console"


That’s it! If you could just send over the CSV and saved plots that would be great!

p.s. Let me know if you have any questions or if anything isn't working properly.
- Brody